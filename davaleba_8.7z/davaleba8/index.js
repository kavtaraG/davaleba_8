// chalk მოდული ანიჭევს სხვაგადასხვა ფერის სისქეს და ფერს ტერმინალში 
//სტრინგის დალოგვისას



//validator მოდული ახდენს დამოწმებას, რომ მეილი ან ULR ნამდვილად
// მეილი ან URL არის ბულინის მნიშვნელობით დალოგვისას


import validator from 'validator';
console.log(validator.isURL('https://nbg.gov.ge/gw/api/ct/monetarypolicy/currencies/ka/json'));

import chalk from 'chalk';
console.log(chalk.bold.inverse.red('usjfsufhei ifhse '))



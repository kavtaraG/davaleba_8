const expValid = function validator(){
    return 'https://nbg.gov.ge/gw/api/ct/monetarypolicy/currencies/ka/json';
}


export default{
    expValid
}


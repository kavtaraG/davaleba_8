import {test} from 'axios';
console.log(test);
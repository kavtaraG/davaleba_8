
let ul = document.querySelector('#ulid');

   async function test(){
    try{
        let response = await axios.get('https://nbg.gov.ge/gw/api/ct/monetarypolicy/currencies/ka/json');
        response.data[0].currencies.forEach(element => {
            let li = document.createElement('li');
            li.textContent = `${element.code}...${element.rate}...${element.date}`;
            ul.appendChild(li);
        });
    }
    catch(err){
        console.log(`error ${err}`);
    }
}
test()
//axios is not defined

